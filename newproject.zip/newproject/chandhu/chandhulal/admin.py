from django.contrib import admin
from .models import *
# Register your models here.



class job_data(admin.ModelAdmin):
    list_display=("company","place","date","time","cash")
admin.site.register(jobs,job_data)

class user_app_data(admin.ModelAdmin):
    list_display=("name","phone","company","place","email","age","date","time","mode","status")
admin.site.register(user_application,user_app_data)

class Emp_reg(admin.ModelAdmin):
    list_display=("Ename","Ephone","Eemail","Epassword","Ecompany","Elicense")
admin.site.register(E_reg,Emp_reg)

class Usr_reg(admin.ModelAdmin):
    list_display=("Uname","Uphone","Uplace","Uemail","Upassword")
admin.site.register(U_reg,Usr_reg)


