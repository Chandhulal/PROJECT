from django.urls import path
from .import views
urlpatterns=[
    path('',views.sample,name="home"),
    path('about',views.about,name="about"),
    path('reg',views.empolyerreg,name="emprreg"),
    path('login',views.loginview,name="login"),
    path('events',views.events,name="events"), 
    path('user_application/<str:company>/<str:amount>/<str:place>/<str:date>/<str:time>/',views.user_application1,name="user_application"),
    path('logout',views.logout_view,name="logout"),
    path('Ureg',views.userreg,name="userreg"),
    path('job_list',views.job_list,name="job_list"),
    path('add_job',views.job,name="add_job"),
    path('job_request',views.job_request,name="job_request"),
    path('userapps',views.userapps,name="userapps"),
    path('E_profile',views.E_profile,name="E_profile"),
    path('U_profile',views.U_profile,name="U_profile"),
    path('main_admin',views.main_admin,name="main_admin"),   
]




