from django.db import models
from django.contrib.auth.models import User
# Create your models here.

class U_reg(models.Model):
    Uname=models.CharField(max_length=20,blank=False) 
    Uphone=models.IntegerField(blank=False)
    Uplace=models.CharField(max_length=20,blank=False,default="place")
    Uemail=models.CharField(max_length=20,blank=False)
    Upassword=models.CharField(max_length=10,blank=False)
  
class E_reg(models.Model):
    Ename=models.CharField(max_length=20,blank=False) 
    Ephone=models.IntegerField(blank=False)
    Eemail=models.CharField(max_length=20,blank=False)
    Epassword=models.CharField(max_length=10,blank=False)
    Ecompany=models.CharField(max_length=20,blank=False)
    Elicense=models.IntegerField(blank=False)
    
    
class jobs(models.Model):
    name=models.CharField(max_length=20,blank=False,default="name")
    company=models.CharField(max_length=20,blank=False)
    place=models.CharField(max_length=20,blank=False)
    date=models.DateField()
    time=models.TimeField()
    cash=models.IntegerField()
    
class user_application(models.Model):
    name=models.CharField(max_length=20,blank=False)
    phone=models.IntegerField(default=1)
    company=models.CharField(max_length=20,blank=False)
    place=models.CharField(max_length=20,blank=False)
    email=models.CharField(max_length=20,blank=False)
    age=models.IntegerField(default=1)
    date=models.DateField(default=1)
    time=models.TimeField(default=1)
    cash=models.IntegerField(default=1)
    mode=models.CharField(max_length=20,blank=False)
    feedback=models.CharField(max_length=20,default=1)
    status=models.IntegerField(default=2)
    
    
    

    
    

    
    
    
