from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from django.contrib import messages
from .models import*
from django.contrib.auth import authenticate,login,logout
from django.views.decorators.csrf import csrf_exempt
from django.http import HttpResponse


# Create your views here.

def about(request):
    return render(request,'about.html')
def events(request):
    return render(request,'events.html')

def sample(request):
    return render(request,'index.html')

def main_admin(request):
    tmp=E_reg.objects.all()
    if request.method == 'POST':
            userid=request.POST.get("id")
            temp = E_reg.objects.get(id=userid)
            E_reg.objects.filter(id=userid).delete()
            temp.delete()
            return render(request,'main_admin.html',{'tmp':tmp})
    return render(request,'main_admin.html',{'tmp':tmp})

def U_profile(request):   
    prof=U_reg.objects.filter(Uname=request.user.username)
    return render(request,'U_profile.html',{'prof':prof})

def E_profile(request):   
    profile=E_reg.objects.filter(Ename=request.user.username)
    return render(request,'E_profile.html',{'pro':profile})

def userapps(request):
    applications=user_application.objects.all()
    return render(request,'U_Job_apps.html',{'user_apps':applications})

def job_list(request):
    jb=jobs.objects.filter(name=request.user.username)
    return render(request,'see_job.html',{'jobs':jb})


def job_request(request):
    if request.method == "POST":
        ids = request.POST.get('id')
        Pplace = request.POST.get('place')
        Pdate = request.POST.get('date')
        Ptime = request.POST.get('time')
        Pcash = request.POST.get('cash')
        Pmode = request.POST.get('mode')
        Pcompany = request.POST.get('company')
        status = request.POST.get('status')
        
        if ids is not None:
            usrapp = user_application.objects.get(id=ids)
            usrapp.place = Pplace
            usrapp.cash = Pcash
            usrapp.mode = Pmode
            usrapp.company = Pcompany
            usrapp.status = status
            usrapp.save()

    emp_obj = jobs.objects.filter(name=request.user).first()
    rqst1 = None 
    if emp_obj is not None:
        rqst1 = user_application.objects.filter(company=emp_obj.company)
    return render(request, 'request.html', {'applications': rqst1})



def job(request):
    if request.method=="POST":
        place=request.POST['place']
        date=request.POST['date']
        time=request.POST['time']
        cash=request.POST['cash']      
        cmp=E_reg.objects.filter(Ename=request.user.username)
        {'cmp':cmp}
        for i in cmp:
            print(i.Ecompany)       
        job=jobs()
        job.place=place
        job.date=date
        job.time=time
        job.cash=cash
        job.name=request.user.username
        job.company=i.Ecompany  
        job.save()       
    return render(request,'jobs.html')

def logout_view(request):
    logout(request)
    return render(request,'index.html')


def empolyerreg(request):
    if request.method=='POST':
        name=request.POST['name']
        phone=request.POST['phone']
        company=request.POST['company']
        license=request.POST['licence']
        email=request.POST['email']
        password=request.POST['password']       
        if User.objects.filter(username=name):
            messages.error(request,'change name')
            print("existing user")
        elif len(phone) != 10:
             messages.error(request,'check the phone number')
        elif len(password) != 4:
            messages.error(request,'password is too small')
        elif len(license) != 14:
            messages.error(request,'check the license')
        else:
            print("not existing")
            User.objects._create_user(username=name,email=email,password=password,last_name="1")
            employer=E_reg()
            employer.Ename=name          
            employer.Ephone=phone    
            employer.Epassword=password               
            employer.Ecompany=company
            employer.Elicense=license
            employer.Eemail=email
            employer.save()            
    return render(request,'e_register.html')


def userreg(request):
    if request.method=='POST':
        name=request.POST['name']
        phone=request.POST['phone']
        place=request.POST['place']      
        email=request.POST['email']
        password=request.POST['password']
        if User.objects.filter(username=name):
            messages.error(request,'change name')
            print("existing user")
        elif len(phone) != 10:
                 messages.error(request,'check the phone number')
        elif len(password) != 4:
            messages.error(request,'password is too small')
        else:
            print("not existing")
            User.objects._create_user(username=name,email=email,password=password,last_name="2")
            employee=U_reg()
            employee.Uname=name
            employee.Uphone=phone     
            employee.Uplace=place      
            employee.Upassword=password
            employee.Uemail=email
            employee.save()     
    return render(request,'register.html')

@csrf_exempt
def loginview(request):
    if request.method == 'POST':
        name = request.POST['Uname']
        password = request.POST['password']
        user = authenticate(username=name, password=password)
        if user is not None:
            login(request, user)
            if user.is_superuser:
                return redirect('main_admin')
            elif user.last_name == '1':
                return render(request, 'free.html')
            elif user.last_name == '2':
                job = jobs.objects.all()
                return render(request, 'events.html', {'jobs': job})
            else:
                messages.error(request,'check your username and password')
                return render(request, 'login.html')
        else:
            messages.error(request,'check your username and password')
            return render(request, 'login.html')
    return render(request, 'login.html')

       
       
def user_application1(request,place,company,amount,date,time):
    if request.method=='POST':    
        phn=request.POST['phone']
        age=request.POST['age']
        U_place=request.POST['user_place']
        email=request.POST['email']
        mod_trans=request.POST['transportation']
        print(mod_trans,phn,age,email,U_place)
        cs=jobs.objects.filter(company=company,place=place,date=date,cash=amount,time=time)
        {'cs':cs}
        for i in cs:
            print('pass')
            print(i.cash)
        if jobs.objects.filter(company=company,place=place,date=date,cash=amount,time=time):
            usr=user_application()
            usr.name=request.user.username
            usr.company=company
            usr.date=date
            usr.cash=i.cash
            usr.phone=phn
            usr.age=age
            usr.time=time
            usr.place=U_place
            usr.email=email
            usr.mode=mod_trans
            usr.save()        
    job=jobs.objects.filter(company=company,place=place,date=date,cash=amount)
    return render(request,'user_application.html',{'jobs':job})
       
