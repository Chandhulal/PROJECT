export const baseUrl='https://api.themoviedb.org/3';
export const API_KEY ="a712cf051a16a3f04c701935cb6c398b";
export const imageUrl ="https://image.tmdb.org/t/p/original";
