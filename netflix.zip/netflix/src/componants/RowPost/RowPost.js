import React, { useEffect, useState } from 'react';
import './RowPost.css';
import axios from 'axios';
import { imageUrl, API_KEY } from '../../constants/constants';
import YouTube from 'react-youtube';

function RowPost(props) {
  const [movies, setMovies] = useState([])
  const [urlId, setUrlId] = useState("")
  useEffect(() => {
    axios.get(props.url)
      .then((response) => {
        setMovies(response.data.results)
      })
      .catch((error) => {
        console.error('Error fetching the TV show data:', error);
      });
  }, [props.url]);

  const opts = {
    height: '350',
    width: '600',
    playerVars: {
      // https://developers.google.com/youtube/player_parameters
      autoplay: 1,
    },
  };
  const handleMovie = (id) => {
    axios.get(`https://api.themoviedb.org/3/movie/${id}/videos?api_key=${API_KEY}&language=en-US`)
      .then((response) => {
        // Check for status code 404
        if (response.status === 404) {
          console.log('Video not found (404)');
          setUrlId(null); // Reset if video not found
          return;
        }

        const videos = response.data.results;
        if (videos.length > 0) {
          // Check for the first available YouTube trailer
          const trailer = videos.find(video => video.type === 'Trailer' && video.site === 'YouTube');
          if (trailer) {
            setUrlId(trailer)

          } else {
            console.log('Trailer Not Available');
            <pop-up>("Video Not Available")</pop-up>
            setUrlId(null); // Reset if no trailer is available
          }
        } else {
          console.log('No Videos Found');
          setUrlId(null); // Reset if no videos are found
        }
      })
      .catch((error) => {
        // Handle network or other errors
        if (error.response && error.response.status === 404) {
          console.log('Video not found (404)');
        } else {
          console.error('Error fetching video data:', error.message || error);
        }
        setUrlId(null); // Reset on error
      });
  };

  return (
    <div className='row'>
      <h2>{props.title}</h2>
      <div className='posters'>
        {movies.map((obj) => (
          <div key={obj.id} className="movie-container">
            <img
              onClick={() => handleMovie(obj.id)}
              className={props.isSmall ? 'smallPoster' : 'poster'}
              src={`${imageUrl + obj.backdrop_path}`}
              alt={obj.title}
            />
            <p className="movie-title">{obj.title}</p>
          </div>
        ))}
      </div>
      {urlId && <YouTube videoId={urlId.key} opts={opts} />}
    </div>
  );
}

export default RowPost;
