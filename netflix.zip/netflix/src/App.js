import React from 'react';
import NavBar from './componants/NavBar/NavBar';
import './App.css';
import Banner from './componants/Banner/Banner';
import RowPost from './componants/RowPost/RowPost';
import { originals,action,romance } from './urls';

function App() {
  return (
    <div className="App">
      <NavBar />
      <Banner />
      <RowPost url={originals} title="Netflix Originals" />
      <RowPost url={action} title="Action" isSmall />
      <RowPost url={romance} title="Romance" isSmall />
    </div>
  );
}
export default App;
